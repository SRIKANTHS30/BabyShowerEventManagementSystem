package com.example.baby.model;

public enum Role {
    USER,
    ADMIN
}
