package com.example.baby;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BabyApplicationTests {

	@Test
	void contextLoads() {
	}

}
